CREATE TABLE Услуги
(
  Код_услуги INT NOT NULL,
  Наименование VARCHAR NOT NULL,
  Описание VARCHAR NOT NULL,
  Стоимость VARCHAR NOT NULL,
  PRIMARY KEY (Код_услуги)
);

CREATE TABLE Должности
(
  Обязанности VARCHAR NOT NULL,
  Наименование_должности VARCHAR NOT NULL,
  Код_должности INT NOT NULL,
  Оклад VARCHAR NOT NULL,
  Требования VARCHAR NOT NULL,
  PRIMARY KEY (Код_должности)
);

CREATE TABLE Сотрудники
(
  Код_сотрудника INT NOT NULL,
  Возраст INT NOT NULL,
  Пол VARCHAR NOT NULL,
  Паспортные_данные VARCHAR NOT NULL,
  Адрес VARCHAR NOT NULL,
  ФИО VARCHAR NOT NULL,
  Телефон VARCHAR NOT NULL,
  Код_должности INT NOT NULL,
  PRIMARY KEY (Код_сотрудника),
  FOREIGN KEY (Код_должности) REFERENCES Должности(Код_должности)
);

CREATE TABLE Номера
(
  Код_номера INT NOT NULL,
  Описание VARCHAR NOT NULL,
  Стоимость VARCHAR NOT NULL,
  Наименование VARCHAR NOT NULL,
  Вместимость VARCHAR NOT NULL,
  Кот_сотрудника INT,
  PRIMARY KEY (Код_номера),
  FOREIGN KEY (Код_сотрудника_) REFERENCES Сотрудники(Код_сотрудника_)
);

CREATE TABLE Клиенты
(
  ФИО VARCHAR NOT NULL,
  Стоимость VARCHAR NOT NULL,
  Дата_заселение DATE NOT NULL,
  Дата_выезда DATE NOT NULL,
  Паспортные_данные VARCHAR NOT NULL,
  Код_клиента INT NOT NULL,
  Код_номера INT,
  Код_сотрудника_ INT NOT NULL,
  Код_услуги INT,
  Код_услуги_3Код_услуги INT,
  Код_услуги_1Код_услуги INT,
  PRIMARY KEY (Код_клиента),
  FOREIGN KEY (Код_номера) REFERENCES Номера(Код_номера),
  FOREIGN KEY (Код_сотрудника) REFERENCES Сотрудники(Код_сотрудника)
  FOREIGN KEY (Код_услуги_) REFERENCES Услуги(Код_услуги_),
  FOREIGN KEY (Код_услуги_1) REFERENCES Услуги(Код_услуги),
  FOREIGN KEY (Код_услуги_2) REFERENCES Услуги(Код_услуги),
  FOREIGN KEY (Код_услуги_3) REFERENCES Услуги(Код_услуги),
);