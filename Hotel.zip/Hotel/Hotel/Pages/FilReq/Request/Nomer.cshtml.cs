using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Hotel.Models;
using Hotel.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Hotel.Pages.FilReq.Request
{
    public class NomerModel : PageModel
    {
        private readonly Hotel.Data.Hotel_Context _context;

        public NomerModel(Hotel.Data.Hotel_Context context)
        {
            _context = context;
        }

        public IList<Hotel.Models.Rooms> Rooms { get; set; }
        public IList<Hotel.Models.Employee> Employees { get; set; }
        public async Task OnGetAsync()
        {
            Rooms = await _context.Rooms.ToListAsync();
            Employees = await _context.Employee.ToListAsync();
        }
    }
}
