﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Hotel.Models;
using Hotel.Data;

namespace Hotel.Pages.Room
{
    public class IndexModel : PageModel
    {
        private readonly Hotel.Data.Hotel_Context _context;

        public IndexModel(Hotel.Data.Hotel_Context context)
        {
            _context = context;
        }

        public IList<Rooms> Rooms { get;set; }
        public IList<Hotel.Models.Employee> Employee { get;set; }

        public async Task OnGetAsync()
        {
            Rooms = await _context.Rooms.ToListAsync();
            Employee = await _context.Employee.ToListAsync();
        }
    }
}
