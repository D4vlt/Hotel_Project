﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Hotel.Models;
using Hotel.Data;

namespace Hotel.Pages.Positions
{
    public class IndexModel : PageModel
    {
        private readonly Hotel.Data.Hotel_Context _context;

        public IndexModel(Hotel.Data.Hotel_Context context)
        {
            _context = context;
        }

        public IList<Hotel.Models.Positions> Positions { get;set; }

        public async Task OnGetAsync()
        {
            Positions = await _context.Positions.ToListAsync();
        }
    }
}
