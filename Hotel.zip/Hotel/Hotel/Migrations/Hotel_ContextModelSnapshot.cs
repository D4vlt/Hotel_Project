﻿using System;
using Hotel.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Hotel.Migrations
{
    [DbContext(typeof(Hotel_Context))]
    partial class Hotel_ContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "3.1.8")
                .HasAnnotation("Relational:MaxIdentifierLength", 128)
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("Hotel.Models.Clients", b =>
                {
                    b.Property<long>("ID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint")
                        .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

                    b.Property<int>("Age")
                        .HasColumnType("int");

                    b.Property<DateTime>("Check_in_date")
                        .HasColumnType("datetime2");

                    b.Property<DateTime>("Check_out_date")
                        .HasColumnType("datetime2");

                    b.Property<long?>("EmployeeID")
                        .HasColumnType("bigint");

                    b.Property<string>("FIO")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Passport_data")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Price")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("RoomID")
                        .HasColumnType("bigint");

                    b.Property<long?>("Service1ID")
                        .HasColumnType("bigint");

                    b.Property<long?>("Service2ID")
                        .HasColumnType("bigint");

                    b.Property<long?>("Service3ID")
                        .HasColumnType("bigint");

                    b.HasKey("ID");

                    b.ToTable("Clients");
                });

            modelBuilder.Entity("Hotel.Models.Employee", b =>
                {
                    b.Property<long>("ID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint")
                        .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

                    b.Property<string>("Address")
                        .HasColumnType("nvarchar(max)");

                    b.Property<int>("Age")
                        .HasColumnType("int");

                    b.Property<long?>("ClientsID")
                        .HasColumnType("bigint");

                    b.Property<string>("FIO")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Gender")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Passport_data")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("PositionID")
                        .HasColumnType("bigint");

                    b.Property<long?>("RoomsID")
                        .HasColumnType("bigint");

                    b.Property<int>("Telephone")
                        .HasColumnType("int");

                    b.HasKey("ID");

                    b.HasIndex("ClientsID");

                    b.HasIndex("RoomsID");

                    b.ToTable("Employee");
                });

            modelBuilder.Entity("Hotel.Models.Positions", b =>
                {
                    b.Property<long>("ID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint")
                        .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

                    b.Property<string>("Duties")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("EmployeeID")
                        .HasColumnType("bigint");

                    b.Property<string>("Name_of_the_position")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Requirements")
                        .HasColumnType("nvarchar(max)");

                    b.Property<int>("Salary")
                        .HasColumnType("int");

                    b.HasKey("ID");

                    b.HasIndex("EmployeeID");

                    b.ToTable("Positions");
                });

            modelBuilder.Entity("Hotel.Models.Rooms", b =>
                {
                    b.Property<long>("ID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint")
                        .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

                    b.Property<string>("Appellation")
                        .HasColumnType("nvarchar(max)");

                    b.Property<string>("Capacity")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("ClientsID")
                        .HasColumnType("bigint");

                    b.Property<string>("Description")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("EmployeeID")
                        .HasColumnType("bigint");

                    b.Property<int>("Price")
                        .HasColumnType("int");

                    b.HasKey("ID");

                    b.HasIndex("ClientsID");

                    b.ToTable("Rooms");
                });

            modelBuilder.Entity("Hotel.Models.Services", b =>
                {
                    b.Property<long>("ID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint")
                        .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

                    b.Property<string>("Appellation")
                        .HasColumnType("nvarchar(max)");

                    b.Property<long?>("ClientsID")
                        .HasColumnType("bigint");

                    b.Property<long?>("ClientsID1")
                        .HasColumnType("bigint");

                    b.Property<long?>("ClientsID2")
                        .HasColumnType("bigint");

                    b.Property<string>("Description")
                        .HasColumnType("nvarchar(max)");

                    b.Property<int>("Price")
                        .HasColumnType("int");

                    b.HasKey("ID");

                    b.HasIndex("ClientsID");

                    b.HasIndex("ClientsID1");

                    b.HasIndex("ClientsID2");

                    b.ToTable("Services");
                });

            modelBuilder.Entity("Hotel.Models.Employee", b =>
                {
                    b.HasOne("Hotel.Models.Clients", null)
                        .WithMany("Employee")
                        .HasForeignKey("ClientsID");

                    b.HasOne("Hotel.Models.Rooms", null)
                        .WithMany("Employee")
                        .HasForeignKey("RoomsID");
                });

            modelBuilder.Entity("Hotel.Models.Positions", b =>
                {
                    b.HasOne("Hotel.Models.Employee", null)
                        .WithMany("ID_Position")
                        .HasForeignKey("EmployeeID");
                });

            modelBuilder.Entity("Hotel.Models.Rooms", b =>
                {
                    b.HasOne("Hotel.Models.Clients", null)
                        .WithMany("Room")
                        .HasForeignKey("ClientsID");
                });

            modelBuilder.Entity("Hotel.Models.Services", b =>
                {
                    b.HasOne("Hotel.Models.Clients", null)
                        .WithMany("Service1")
                        .HasForeignKey("ClientsID");

                    b.HasOne("Hotel.Models.Clients", null)
                        .WithMany("Service2")
                        .HasForeignKey("ClientsID1");

                    b.HasOne("Hotel.Models.Clients", null)
                        .WithMany("Service3")
                        .HasForeignKey("ClientsID2");
                });
#pragma warning restore 612, 618
        }
    }
}
